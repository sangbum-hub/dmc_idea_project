from konlpy.tag import Okt
from elasticsearch import Elasticsearch
import pandas as pd

# 엘라스틱 API
def search_table(type, year, BusinessNum=None, size=10000):
    es = Elasticsearch(
            host='0.0.0.0',
            port=9200,
            http_auth=('1111', '1111'),
            timeout = 90,
            retry_on_timeout=False
        )

    bsN = {}
    size = size
    ans = [{'term' : {'DataType' : type}}]
    if BusinessNum != None:
        size = 5000
        bsN = {'term' : {'BusinessNum' : BusinessNum}}
        if type == "naver_news":
            fieldName = "NewsDate"
        elif type == "naver_cafe":
            fieldName = "CafeDate"
        elif type == "naver_blog":
            fieldName = "PostDate"
        dateRange = {"range": {
            f"Data.{fieldName}":{
            "gte": f"{year}-01-01",
            "lt": f"{year+1}-01-01",
            "format": "yyyy-MM-dd"
            }
        }}
        ans.append(bsN)
        ans.append(dateRange)
    
    query = {
        'size' : size,
        'query' : {
            'bool' : {
                "filter":ans
            }
        }
    }
    
    res = es.search(index = 'source_data', doc_type='_doc', body = query)['hits']['hits']
    if BusinessNum != None:
        if res == [] :
            return []
        else: return  pd.json_normalize(res)
    else:
        res = pd.json_normalize(res)
        return res

# Open Korean Text 형태소 분석기
okt = Okt()

# 사전 불러오기
file = 'SentiWord_Dict.txt'   # 감성 키워드 사전
wordnet_df = pd.read_csv(file, sep = '\t')
wordnet_df.dropna(inplace = True)
wordnet_df.columns = ['word', 'score']
wordnet_dict = {}
for word, score in zip(wordnet_df.iloc[:,0], wordnet_df.iloc[:,-1]):
    wordnet_dict[word] = score

file = "사회적책임(CSR)_Keywords().txt"   # 사회적책임 키워드 사전
rep5_word_df = pd.read_csv(file, sep='\t', encoding='cp949')
rep5_word_df.dropna(inplace = True)
rep5_word_df.columns = ['word', 'score']
rep5_word_dict = {}
for word, score in zip(rep5_word_df.iloc[:,0], rep5_word_df.iloc[:,-1]):
    rep5_word_dict[word] = score


# 평판 지수: 비정형 데이터 분석 프로세스
def unstructure_process(x, wordnet_dict = wordnet_dict, target_col = 'ReviewTitle'):
  '''
  input:
  1) x: 블로그 또는 카페 데이터(각 데이터는 포스팅 제목, 포스팅 내용, 뉴스 제목을 포함)
  2) wordnet_dict: 감성 사전
  3) rep5_word_dict: 사회적 책임 사전
  4) target_col: 제목 혹은 내용을 선택할 수 있음. 아래 네 가지 옵션 중 하나를 선택하여 사용함.
                 'CafeTitle' : 포스팅 제목(네이버 카페), 'CafeContent' : 포스팅 내용(네이버 카페)
                 'PostTitle' : 포스팅 제목(네이버 블로그), 'PostContent' : 포스팅 미리보기(네이버 블로그)
                 'NewsTitle' : 뉴스 제목(네이버 뉴스)
  '''
  # 감성분석 사전 점수 도출
  sent = [] ; sentiment = 0 
  target_col = "_source.Data."+target_col
  
  if len(x) == 0:
    return 0
  # 감성 분석을 수행하는 경우에는, 감성 분석 점수를 반환(비정형 데이터)
  if wordnet_dict == rep5_word_dict:  # 사회적 책임
    for n in range(len(x)):
      sent.extend(okt.morphs(x.loc[n,target_col]))
  else:       # 감성분석
    for n in range(len(x)):
      sent.extend(okt.morphs(x.loc[n,target_col]))

  keyword = []
  for d in sent:
    if d in wordnet_dict.keys():
      sentiment += wordnet_dict[d]  # 감성 분석 사전 형태: {'고마운': 2.0, '계속 공허한': -1.0, ..., } 등의 단어-점수 pair
      keyword.append(d)             
  keyword = set(keyword)    # --> 세윤에서 어떤 형태로 필요한지 몰라서, 일단 사회적 책임 키워드를 중복 없이 하나씩 적용
  return sentiment, keyword


if __name__=="__main__":
  """
  type: naver_blog, naver_news
  연도: 2021
  사업자번호: 엘라스틱DB에 데이터가 있는 사업자번호를 사용
  """
  data_type = 'naver_blog'
  year=2021
  BizNum = '1278661140' 
  blog = search_table(data_type, year, BusinessNum=BizNum)
  print(f"{data_type}에 저장된 {BizNum}의 data:", blog)
  print("==================================================")
  blogTitleScore, keyword = unstructure_process(blog, target_col="PostTitle")
  print("블로그 감성 점수:", blogTitleScore)
  print("키워드:", keyword)
  print()

  data_type = 'naver_news'
  BizNum = '2148687901'
  news = search_table(data_type, year, BusinessNum=BizNum)
  print(f"{data_type}에 저장된 {BizNum}의 data:", blog)
  print("==================================================")
  NewsCount_social, keyword= unstructure_process(news, rep5_word_dict, target_col='NewsContent')
  print("사회적 책임 점수:", NewsCount_social)
  print("키워드:", keyword)